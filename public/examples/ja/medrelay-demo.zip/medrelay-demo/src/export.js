// スキーマで制限したフィールドのみをエクスポートし、生の信号と受信時刻は除外する。
export function exportCsv(recorder) {
  const rows = recorder.packets().map(p => [p.deviceId, p.recordedAt, p.sequence, p.samples.length].join(','));
  return ['device_id,recorded_at,sequence,sample_count', ...rows].join('\n');
}
