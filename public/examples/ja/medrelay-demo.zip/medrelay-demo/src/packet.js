import { z } from 'zod';

// 文書化用の合成パケットのみを受け付ける。臨床範囲や生理学的しきい値は定義しない。
export const packetSchema = z.object({
  deviceId: z.string().regex(/^[A-Z0-9-]{1,32}$/),
  recordedAt: z.string().datetime(),
  sequence: z.number().int().nonnegative().safe(),
  samples: z.array(z.number().finite()).min(1).max(256),
}).strict();

export function parsePacket(input) {
  return packetSchema.parse(input);
}
