import test from 'node:test';
import assert from 'node:assert/strict';
import { Recorder, MAX_RETAINED_PACKETS, STALE_AFTER_MS } from '../src/recorder.js';
import { exportCsv } from '../src/export.js';

const packet = (sequence = 1) => ({ deviceId: 'DEMO-01', recordedAt: '2026-10-01T09:00:00Z', sequence, samples: [0.1, 0.2] });

test('検証されていない入力と追加フィールドは保存しない', () => {
  const r = new Recorder();
  assert.throws(() => r.accept({ ...packet(), samples: [Infinity] }));
  assert.throws(() => r.accept({ ...packet(), patientName: 'not-allowed' }));
  assert.equal(r.snapshot().retainedCount, 0);
});

test('重複・逆順のシーケンス番号を拒否し、機器ごとの順序を独立して管理する', () => {
  const r = new Recorder();
  r.accept(packet(2));
  assert.throws(() => r.accept(packet(2)), /PACKET_OUT_OF_ORDER/);
  assert.throws(() => r.accept(packet(1)), /PACKET_OUT_OF_ORDER/);
  r.accept({ ...packet(1), deviceId: 'DEMO-02' });
  assert.equal(r.snapshot().receivedCount, 2);
});

test('保持上限を超えると最も古いパケットを削除する', () => {
  const r = new Recorder();
  for (let i = 0; i <= MAX_RETAINED_PACKETS; i++) r.accept(packet(i));
  assert.equal(r.snapshot().retainedCount, MAX_RETAINED_PACKETS);
  assert.equal(r.packets()[0].sequence, 1);
});

test('受信前の状態と鮮度の境界条件を区別する', () => {
  const r = new Recorder();
  assert.equal(r.snapshot(0).connection, 'no-data');
  r.accept(packet(), 0);
  assert.equal(r.snapshot(STALE_AFTER_MS).connection, 'recent');
  assert.equal(r.snapshot(STALE_AFTER_MS + 1).connection, 'stale');
});

test('エクスポートはメタデータのみを含み、取得結果から内部状態を変更できない', () => {
  const r = new Recorder();
  r.accept(packet(), 0);
  r.packets()[0].samples[0] = 99;
  assert.equal(r.packets()[0].samples[0], 0.1);
  assert.equal(exportCsv(r), 'device_id,recorded_at,sequence,sample_count\nDEMO-01,2026-10-01T09:00:00Z,1,2');
});
