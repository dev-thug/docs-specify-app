import test from 'node:test';
import assert from 'node:assert/strict';
import { exportTasks } from '../src/export-tasks.js';

const task = { id: 'DEMO-01', title: 'サンプルタスク', status: 'open' };

test('オーナーと編集者はエクスポートでき、閲覧者は拒否される', () => {
  for (const role of ['owner', 'editor']) assert.match(exportTasks({ role, tasks: [task] }), /DEMO-01/);
  assert.throws(() => exportTasks({ role: 'viewer', tasks: [task] }), /ACCESS_DENIED/);
});

test('1,000件は許可し、超えると切り詰めずに拒否する', () => {
  assert.equal(exportTasks({ role: 'owner', tasks: Array(1000).fill(task) }).split('\n').length, 1001);
  assert.throws(() => exportTasks({ role: 'owner', tasks: Array(1001).fill(task) }), /EXPORT_LIMIT_EXCEEDED/);
});

test('カンマと引用符をCSVセル形式でエスケープする', () => {
  assert.equal(exportTasks({ role: 'editor', tasks: [{ ...task, title: '会議, "レビュー"' }] }), 'id,title,status\n"DEMO-01","会議, ""レビュー""","open"');
});

test('数式の接頭辞と先頭の空白を含む入力を文字列としてエクスポートする', () => {
  assert.match(exportTasks({ role: 'owner', tasks: [{ ...task, title: ' =1+1' }] }), /"' =1\+1"/);
});

test('未定義の状態と欠落したフィールドを拒否する', () => {
  assert.throws(() => exportTasks({ role: 'editor', tasks: [{ ...task, status: 'unknown' }] }), /INVALID_TASK/);
  assert.throws(() => exportTasks({ role: 'editor', tasks: [{}] }), /INVALID_TASK/);
});
