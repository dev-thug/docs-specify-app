# RelayDesk Demo

SpecifyのRAG活用事例を再現するための合成資料とコードです。実際のSpecifyや顧客企業のセキュリティポリシー・サービス機能ではありません。実際の個人情報・顧客資料・認証情報は含まれていません。

## 資料

- `sources/relaydesk-security-current.md`: 現行のデモ用ポリシー。
- `sources/relaydesk-security-retired.md`: 廃止された以前の回答。現行の回答として使用しないでください。
- `sources/relaydesk-project-brief.md`: 要望と実装の違いを確認するための引き継ぎ資料。
- `sources/relaydesk-release-brief.md`: 1.4の変更範囲と顧客向け案内の基準。
- `sources/relaydesk-faq-before.md`: 更新対象の以前のFAQ。
- `sources/relaydesk-code-snapshot.md`: コードとテストの固定コピー。

`sources/`のMarkdownファイルをワークスペースにアップロードし、元の資料名と文書IDを指定して質問します。検索に反映されているかと、参照している資料のバージョンを確認してください。検索結果がないことを理由に、資料が存在しないと断定しないでください。

## コード

1.4デモ版では、`src/export-tasks.js`にCSVエクスポートのライブラリを実装しました。Node.js 24以上で`npm test`と`npm run demo`を実行して確認します。外部依存関係がないため、インストールは不要です。

実装上の上限は1,000件です。企画メモにある10,000件の要望と区別してください。ZIP機能は実装していません。ロールのパラメーターは検査しますが、実際のログイン・権限付与、Web UI、サーバー、データベース、顧客アカウントは実装していません。

`sources/`にあるTLS・暗号化・削除期間などは架空のポリシー入力です。コードで実装された事実と混同しないでください。引き継ぎの結果では、コードで確認できないデプロイ・セキュリティ・運用の手順を未確認として残します。
