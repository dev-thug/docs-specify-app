import { exportTasks } from './export-tasks.js';

console.log(exportTasks({
  role: 'editor',
  tasks: [
    { id: 'DEMO-01', title: '顧客向け案内のレビュー', status: 'open' },
    { id: 'DEMO-02', title: '引き継ぎ文書の整理', status: 'done' },
  ],
}));
