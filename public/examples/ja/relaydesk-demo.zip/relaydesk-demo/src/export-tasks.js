export const EXPORT_LIMIT = 1000;

// この例は呼び出し元が渡したロールのみを検査する。ログインと権限付与の層は実装範囲外。
export function exportTasks({ role, tasks }) {
  if (!['owner', 'editor'].includes(role)) throw new Error('ACCESS_DENIED');
  if (!Array.isArray(tasks)) throw new Error('INVALID_TASK_LIST');
  if (tasks.length > EXPORT_LIMIT) throw new Error('EXPORT_LIMIT_EXCEEDED');
  const rows = tasks.map(task => {
    if (!task || typeof task.id !== 'string' || typeof task.title !== 'string' || !['open', 'done'].includes(task.status)) {
      throw new Error('INVALID_TASK');
    }
    return [task.id, task.title, task.status].map(csvCell).join(',');
  });
  return ['id,title,status', ...rows].join('\n');
}

function csvCell(value) {
  const text = /^[=+@-]/.test(value.trimStart()) ? "'" + value : value;
  return '"' + text.replaceAll('"', '""') + '"';
}
