# RelayDesk Demo コードスナップショット 1.4

文書ID: RD-CODE-14。ソースコミット: af26ee9。この文書は合成サンプルコードの固定コピーであり、その後のリポジトリの変更を自動的には反映しません。実サービスのデプロイ・セキュリティ統制の実装を主張する資料ではありません。

## package.json

```json
{
  "name": "relaydesk-demo",
  "version": "1.4.0",
  "private": true,
  "type": "module",
  "engines": { "node": ">=24" },
  "scripts": { "test": "node --test test/*.test.js", "demo": "node src/demo.js" }
}
```

## src/export-tasks.js

```javascript
export const EXPORT_LIMIT = 1000;

// この例は呼び出し元が渡したロールのみを検査する。ログインと権限付与の層は実装範囲外。
export function exportTasks({ role, tasks }) {
  if (!['owner', 'editor'].includes(role)) throw new Error('ACCESS_DENIED');
  if (!Array.isArray(tasks)) throw new Error('INVALID_TASK_LIST');
  if (tasks.length > EXPORT_LIMIT) throw new Error('EXPORT_LIMIT_EXCEEDED');
  const rows = tasks.map(task => {
    if (!task || typeof task.id !== 'string' || typeof task.title !== 'string' || !['open', 'done'].includes(task.status)) {
      throw new Error('INVALID_TASK');
    }
    return [task.id, task.title, task.status].map(csvCell).join(',');
  });
  return ['id,title,status', ...rows].join('\n');
}

function csvCell(value) {
  const text = /^[=+@-]/.test(value.trimStart()) ? "'" + value : value;
  return '"' + text.replaceAll('"', '""') + '"';
}
```

## src/demo.js

```javascript
import { exportTasks } from './export-tasks.js';

console.log(exportTasks({
  role: 'editor',
  tasks: [
    { id: 'DEMO-01', title: '顧客向け案内のレビュー', status: 'open' },
    { id: 'DEMO-02', title: '引き継ぎ文書の整理', status: 'done' },
  ],
}));
```

## test/export-tasks.test.js

```javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import { exportTasks } from '../src/export-tasks.js';

const task = { id: 'DEMO-01', title: 'サンプルタスク', status: 'open' };

test('オーナーと編集者はエクスポートでき、閲覧者は拒否される', () => {
  for (const role of ['owner', 'editor']) assert.match(exportTasks({ role, tasks: [task] }), /DEMO-01/);
  assert.throws(() => exportTasks({ role: 'viewer', tasks: [task] }), /ACCESS_DENIED/);
});

test('1,000件は許可し、超えると切り詰めずに拒否する', () => {
  assert.equal(exportTasks({ role: 'owner', tasks: Array(1000).fill(task) }).split('\n').length, 1001);
  assert.throws(() => exportTasks({ role: 'owner', tasks: Array(1001).fill(task) }), /EXPORT_LIMIT_EXCEEDED/);
});

test('カンマと引用符をCSVセル形式でエスケープする', () => {
  assert.equal(exportTasks({ role: 'editor', tasks: [{ ...task, title: '会議, "レビュー"' }] }), 'id,title,status\n"DEMO-01","会議, ""レビュー""","open"');
});

test('数式の接頭辞と先頭の空白を含む入力を文字列としてエクスポートする', () => {
  assert.match(exportTasks({ role: 'owner', tasks: [{ ...task, title: ' =1+1' }] }), /"' =1\+1"/);
});

test('未定義の状態と欠落したフィールドを拒否する', () => {
  assert.throws(() => exportTasks({ role: 'editor', tasks: [{ ...task, status: 'unknown' }] }), /INVALID_TASK/);
  assert.throws(() => exportTasks({ role: 'editor', tasks: [{}] }), /INVALID_TASK/);
});
```

## CHANGELOG.md

```markdown
# 変更履歴

## 1.4.0 — 文書化デモ版

- `exportTasks`でタスク一覧のCSVエクスポートを追加。
- オーナーと編集者のロールを許可。閲覧者は拒否。
- 一度に最大1,000件。上限を超えるリクエストは黙って切り詰めずに拒否。
- セル内のカンマ・引用符と数式の接頭辞を処理。
- 外部依存関係なしで動作するテストと合成入力の例を追加。

ZIPでの添付ファイルダウンロード、Web UI、認証サーバー、ストレージ暗号化、実際のデプロイは実装していません。`sources/`のポリシー資料はRAGデモ用の架空の入力であり、このライブラリで実装した証拠ではありません。
```
