# MedRelay Demo

A **fictional device-data collection example** for explaining how medical device software development documents are written. It is not a real medical device, diagnostic software, or clinical system, and it contains no patient data. All data is synthetic input.

## Implemented scope

1. Validates the device ID, UTC time, sequence number, and signal sample array of synthetic device packets.
2. Stores only packets whose per-device sequence number increases in an in-memory buffer.
3. Summarizes the latest packet, received count, retained count, and freshness of the communication data.
4. Exports metadata of stored synthetic packets to CSV. Raw signal values are not included in the CSV.

Medical normal/abnormal decisions, clinical alarms, diagnosis, therapy control, patient identification, a network server, and persistent storage are not implemented. The freshness indicator is a technical state showing whether communication data is stale; it is not a clinical alarm.

## Running

With Node.js 24 or later, run `npm ci`, `npm test`, and `npm run demo` in that order. No external accounts or credentials are required.

## Code map

| File | Responsibility |
| --- | --- |
| `src/packet.js` | Zod schema and input packet validation |
| `src/recorder.js` | Sequence checks, in-memory buffer, latest receive state |
| `src/export.js` | CSV metadata export |
| `src/demo.js` | Example run using synthetic input |
| `test/recorder.test.js` | Tests for input validation, ordering, retention limit, freshness, and export |

## Undetermined information needed for document review

This example has no manufacturer-approved intended use, actual users or patient population, medical device classification, safety class, risk acceptance criteria, applicable standards and editions, clinical performance requirements, risk analysis, usability evaluation, SOUP anomaly list evaluation, or approval records. Generated documents must leave these items as undetermined or `[GAP]`.

The automated tests confirm the behavior of this example implementation and are not evidence of medical device verification or clinical evaluation. Do not mistake the existence of test files for execution results or an approved test protocol.

## External software

The runtime dependency is Zod 3.25.17, used in `src/packet.js`. Check exact transitive dependencies and license evidence in `package-lock.json` and the distributed package. Known anomaly evaluation and safety impact evaluation have not been performed.
