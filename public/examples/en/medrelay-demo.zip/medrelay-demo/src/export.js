// Exports only the fields restricted by the schema, excluding raw signals and receive times.
export function exportCsv(recorder) {
  const rows = recorder.packets().map(p => [p.deviceId, p.recordedAt, p.sequence, p.samples.length].join(','));
  return ['device_id,recorded_at,sequence,sample_count', ...rows].join('\n');
}
