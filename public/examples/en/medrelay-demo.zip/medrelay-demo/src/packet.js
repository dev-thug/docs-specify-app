import { z } from 'zod';

// Accepts only synthetic packets for documentation. Defines no clinical ranges or physiological thresholds.
export const packetSchema = z.object({
  deviceId: z.string().regex(/^[A-Z0-9-]{1,32}$/),
  recordedAt: z.string().datetime(),
  sequence: z.number().int().nonnegative().safe(),
  samples: z.array(z.number().finite()).min(1).max(256),
}).strict();

export function parsePacket(input) {
  return packetSchema.parse(input);
}
