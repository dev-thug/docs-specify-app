# RelayDesk Demo Security and Operations Policy v2

Document ID: RD-SEC-02. Effective date: 2026-10-06. Status: Current demo material.

This is the policy of a fictional product for reproducing Specify use cases. It does not describe Specify's actual security, certifications, or contract terms. It contains no real customers, personal data, or secrets.

## Basis for current answers

| Item | Approved description for the fictional product |
| --- | --- |
| In transit | Uses TLS 1.2 or later |
| Data at rest | Uses AES-256 storage encryption |
| Data location | The default storage location for service data is the Seoul region |
| Account roles | Owner, editor, viewer. Only owners and editors can export CSV |
| Deletion requests | Operational data is deleted within 30 days of a deletion request. Backup copies expire after a retention cycle of up to 35 days |
| SSO | Available only to invited pilot customers. Not generally available to all customers |
| SOC 2 | No material confirms a completed audit report or certification. Do not answer that it is held |
| Subprocessors | This material has no finalized customer-facing list. Separate confirmation by the contract owner is required |

## Relationship to the previous material

This v2 document replaces the "90 days after a deletion request" answer in RD-SEC-01. Do not use the past 90 days as the current policy in answers. Do not merge operational data deletion and backup expiry into a single period.

## Reviewing customer answers

An owner reviews every answer before submission. Leave unconfirmed items as "Owner confirmation required" and do not guess security controls or audit results.
