# RelayDesk Demo Code Snapshot 1.4

Document ID: RD-CODE-14. Source commit: af26ee9. This document is a fixed copy of the synthetic example code and does not automatically reflect later repository changes. It is not material that claims the deployment or security controls of a real service are implemented.

## package.json

```json
{
  "name": "relaydesk-demo",
  "version": "1.4.0",
  "private": true,
  "type": "module",
  "engines": { "node": ">=24" },
  "scripts": { "test": "node --test test/*.test.js", "demo": "node src/demo.js" }
}
```

## src/export-tasks.js

```javascript
export const EXPORT_LIMIT = 1000;

// This example only checks the role passed by the caller. Sign-in and permission issuance are out of scope.
export function exportTasks({ role, tasks }) {
  if (!['owner', 'editor'].includes(role)) throw new Error('ACCESS_DENIED');
  if (!Array.isArray(tasks)) throw new Error('INVALID_TASK_LIST');
  if (tasks.length > EXPORT_LIMIT) throw new Error('EXPORT_LIMIT_EXCEEDED');
  const rows = tasks.map(task => {
    if (!task || typeof task.id !== 'string' || typeof task.title !== 'string' || !['open', 'done'].includes(task.status)) {
      throw new Error('INVALID_TASK');
    }
    return [task.id, task.title, task.status].map(csvCell).join(',');
  });
  return ['id,title,status', ...rows].join('\n');
}

function csvCell(value) {
  const text = /^[=+@-]/.test(value.trimStart()) ? "'" + value : value;
  return '"' + text.replaceAll('"', '""') + '"';
}
```

## src/demo.js

```javascript
import { exportTasks } from './export-tasks.js';

console.log(exportTasks({
  role: 'editor',
  tasks: [
    { id: 'DEMO-01', title: 'Review customer notice', status: 'open' },
    { id: 'DEMO-02', title: 'Organize handover document', status: 'done' },
  ],
}));
```

## test/export-tasks.test.js

```javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import { exportTasks } from '../src/export-tasks.js';

const task = { id: 'DEMO-01', title: 'Sample task', status: 'open' };

test('owners and editors can export; viewers are rejected', () => {
  for (const role of ['owner', 'editor']) assert.match(exportTasks({ role, tasks: [task] }), /DEMO-01/);
  assert.throws(() => exportTasks({ role: 'viewer', tasks: [task] }), /ACCESS_DENIED/);
});

test('allows 1,000 tasks and rejects more without truncating', () => {
  assert.equal(exportTasks({ role: 'owner', tasks: Array(1000).fill(task) }).split('\n').length, 1001);
  assert.throws(() => exportTasks({ role: 'owner', tasks: Array(1001).fill(task) }), /EXPORT_LIMIT_EXCEEDED/);
});

test('escapes commas and quotes as CSV cells', () => {
  assert.equal(exportTasks({ role: 'editor', tasks: [{ ...task, title: 'Meeting, "review"' }] }), 'id,title,status\n"DEMO-01","Meeting, ""review""","open"');
});

test('exports input with formula prefixes and leading spaces as strings', () => {
  assert.match(exportTasks({ role: 'owner', tasks: [{ ...task, title: ' =1+1' }] }), /"' =1\+1"/);
});

test('rejects undefined statuses and missing fields', () => {
  assert.throws(() => exportTasks({ role: 'editor', tasks: [{ ...task, status: 'unknown' }] }), /INVALID_TASK/);
  assert.throws(() => exportTasks({ role: 'editor', tasks: [{}] }), /INVALID_TASK/);
});
```

## CHANGELOG.md

```markdown
# Changelog

## 1.4.0 — Documentation demo version

- Added CSV export of the task list through `exportTasks`.
- Owner and editor roles are allowed. Viewers are rejected.
- Up to 1,000 tasks at a time. Requests over the limit are rejected instead of being silently truncated.
- Handles commas, quotes, and formula prefixes in cells.
- Added tests and a synthetic-input example that run without external dependencies.

ZIP attachment download, a web UI, an authentication server, storage encryption, and real deployment are not implemented. The policy materials in `sources/` are fictional inputs for the RAG demo and are not evidence that this library implements them.
```
