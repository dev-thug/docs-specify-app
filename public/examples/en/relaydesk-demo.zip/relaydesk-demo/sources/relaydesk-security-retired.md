# RelayDesk Demo Past Security Answers v1 — Retired

Document ID: RD-SEC-01. Written: 2026-08-01. Status: Retired demo material.

This document is an example of past answers for a fictional product and is not an actual Specify policy. As of 2026-10-06, RD-SEC-02 replaces it. Even if these past answers appear in search, do not cite them as the current policy.

## Answers used in the past

- Operational data is deleted 90 days after a deletion request.
- Making SSO available to all customers is under review. This does not mean it is available.
- Preparation for a SOC 2 audit is under review. This does not mean an audit is complete or a report is held.

## Latest material to check

Check document ID RD-SEC-02, "RelayDesk Demo Security and Operations Policy v2," effective 2026-10-06. If it differs from the past answers, use the scope and limits of the current document as written.
