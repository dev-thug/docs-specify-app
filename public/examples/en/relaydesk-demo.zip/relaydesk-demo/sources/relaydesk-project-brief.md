# RelayDesk Demo Project Handover Notes

Document ID: RD-HANDOVER-01. Effective date: 2026-10-06. Status: Fictional project review material.

This material is for demonstration. Owners are written as roles, not real names. The repository in this example contains only a task-list CSV export library and its tests; there is no real customer service, server, or database.

## Requests and current scope

| Request | Status to check now |
| --- | --- |
| Task-list CSV export | Implemented in the 1.4 demo version. Re-check against the code and tests |
| Export up to 10,000 tasks | A planning-stage request. Do not assume it matches the current implementation limit |
| Attachment ZIP download | A follow-up review item. Do not present it as a completed feature in this version |
| Export for every role | Not an approved scope. Only owners and editors are allowed; viewers are rejected |

## Decision log

The first CSV row is id, title, status. Text that a spreadsheet could interpret as a formula is exported as a string. Commas and quotes in titles are also handled according to CSV format. Do not describe this implementation as a full service that includes authentication, encryption, and audit logs.

## Running and owner roles

- Node.js 24 or later. There are no external dependencies to install. Run tests with `npm test` and the synthetic-data example with `npm run demo`.
- Development owner: Confirm exportTasks behavior and test coverage.
- Product owner: Decide follow-up schedules for the 10,000-task request and the ZIP feature.
- Operations owner: Document deployment, monitoring, and recovery procedures for the real service separately.
- Customer support owner: Reflect the current limit and role restrictions in the FAQ.

## Unconfirmed items to leave in the handover

This material does not include the real deployment environment, the access-granting procedure, the incident contact list, recovery test records, or throughput measurements. Do not invent owners, schedules, or completion status.
