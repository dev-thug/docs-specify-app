# RelayDesk Demo 1.4 Changes and Customer Communication Guidelines

Document ID: RD-RELEASE-14. Effective date: 2026-10-06. Status: Communication material for a fictional product demo version.

This material is not a real service release announcement. The dates, features, and policies are a fictional scenario for public use cases. Create a draft for review instead of sending anything to customers.

## Changes included in this version

- Added the ability to export the task list as CSV.
- The CSV columns are id, title, status. Attachments are not included.
- Up to 1,000 tasks at a time. If a request exceeds the limit, ask the user to reduce it and try again.
- Only owners and editors can export. Viewers must ask an authorized owner.
- Text that could be interpreted as a formula, and commas and quotes, are safely handled as CSV text.

## What not to announce

- ZIP attachment download is not in this version.
- Support for 10,000 tasks is only a planning request, not the current limit.
- SSO is unrelated to this CSV change. By policy, it is available only to invited pilot customers.
- There is no evidence to claim response-time improvements, certifications, or unlimited availability for all customers.

## Purpose by audience

The product owner reviews the change summary. Customer support prepares FAQ answers to "Who can use it?", "How many tasks can I export?", and "Are attachments included?". The customer notice explains the results and limits users get before technical implementation names. Do not invent UI menu paths that are not in the source.
