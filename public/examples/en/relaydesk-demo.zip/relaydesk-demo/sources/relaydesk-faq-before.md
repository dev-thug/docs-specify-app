# RelayDesk Demo Customer FAQ — as of 1.3

Document ID: RD-FAQ-13. Version: 1.3. Status: Demo material to be updated against the 1.4 change materials.

This document is a past FAQ for a fictional product. It does not describe actual Specify features.

## Can I export the task list to a file?

Version 1.3 does not provide CSV export of the task list.

## Can viewers change content?

Viewers cannot change task content.

## Can I download attachments as a ZIP?

Not available. It is a follow-up review item, and no release date has been set.

## Can I use SSO right away?

Only invited pilot customers can use it. It is not generally available to all customers.
