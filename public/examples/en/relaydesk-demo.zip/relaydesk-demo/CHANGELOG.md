# Changelog

## 1.4.0 — Documentation demo version

- Added CSV export of the task list through `exportTasks`.
- Owner and editor roles are allowed. Viewers are rejected.
- Up to 1,000 tasks at a time. Requests over the limit are rejected instead of being silently truncated.
- Handles commas, quotes, and formula prefixes in cells.
- Added tests and a synthetic-input example that run without external dependencies.

ZIP attachment download, a web UI, an authentication server, storage encryption, and real deployment are not implemented. The policy materials in `sources/` are fictional inputs for the RAG demo and are not evidence that this library implements them.
