export const EXPORT_LIMIT = 1000;

// This example only checks the role passed by the caller. Sign-in and permission issuance are out of scope.
export function exportTasks({ role, tasks }) {
  if (!['owner', 'editor'].includes(role)) throw new Error('ACCESS_DENIED');
  if (!Array.isArray(tasks)) throw new Error('INVALID_TASK_LIST');
  if (tasks.length > EXPORT_LIMIT) throw new Error('EXPORT_LIMIT_EXCEEDED');
  const rows = tasks.map(task => {
    if (!task || typeof task.id !== 'string' || typeof task.title !== 'string' || !['open', 'done'].includes(task.status)) {
      throw new Error('INVALID_TASK');
    }
    return [task.id, task.title, task.status].map(csvCell).join(',');
  });
  return ['id,title,status', ...rows].join('\n');
}

function csvCell(value) {
  const text = /^[=+@-]/.test(value.trimStart()) ? "'" + value : value;
  return '"' + text.replaceAll('"', '""') + '"';
}
