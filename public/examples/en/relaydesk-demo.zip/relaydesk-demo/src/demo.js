import { exportTasks } from './export-tasks.js';

console.log(exportTasks({
  role: 'editor',
  tasks: [
    { id: 'DEMO-01', title: 'Review customer notice', status: 'open' },
    { id: 'DEMO-02', title: 'Organize handover document', status: 'done' },
  ],
}));
