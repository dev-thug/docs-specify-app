# RelayDesk Demo

Synthetic materials and code for reproducing Specify's RAG use cases. These are not the security policies or service features of Specify or any customer. They contain no real personal data, customer materials, or credentials.

## Materials

- `sources/relaydesk-security-current.md`: Current demo policy.
- `sources/relaydesk-security-retired.md`: Retired previous answers. Do not use them as current answers.
- `sources/relaydesk-project-brief.md`: Handover notes for checking the gap between requests and implementation.
- `sources/relaydesk-release-brief.md`: Scope of the 1.4 changes and customer communication guidelines.
- `sources/relaydesk-faq-before.md`: Previous FAQ to be updated.
- `sources/relaydesk-code-snapshot.md`: Fixed copy of the code and tests.

Upload the Markdown files in `sources/` to your workspace, then ask questions that name the source documents and their document IDs. Check whether the documents appear in search and which version you are reading. Do not conclude that a material does not exist just because search returned nothing.

## Code

The 1.4 demo version implements a CSV export library in `src/export-tasks.js`. Run `npm test` and `npm run demo` with Node.js 24 or later. There are no external dependencies, so no installation step is needed.

The implemented limit is 1,000 tasks. Keep it separate from the 10,000-task request in the planning notes. The ZIP feature is not implemented. The code checks a role parameter, but it does not implement real sign-in, permission issuance, a web UI, a server, a database, or customer accounts.

TLS, encryption, deletion periods, and similar items in `sources/` are fictional policy inputs. Do not confuse them with facts implemented in the code. In handover results, leave deployment, security, and operations procedures that cannot be confirmed from the code as unconfirmed.
