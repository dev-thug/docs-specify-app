import test from 'node:test';
import assert from 'node:assert/strict';
import { exportTasks } from '../src/export-tasks.js';

const task = { id: 'DEMO-01', title: 'Sample task', status: 'open' };

test('owners and editors can export; viewers are rejected', () => {
  for (const role of ['owner', 'editor']) assert.match(exportTasks({ role, tasks: [task] }), /DEMO-01/);
  assert.throws(() => exportTasks({ role: 'viewer', tasks: [task] }), /ACCESS_DENIED/);
});

test('allows 1,000 tasks and rejects more without truncating', () => {
  assert.equal(exportTasks({ role: 'owner', tasks: Array(1000).fill(task) }).split('\n').length, 1001);
  assert.throws(() => exportTasks({ role: 'owner', tasks: Array(1001).fill(task) }), /EXPORT_LIMIT_EXCEEDED/);
});

test('escapes commas and quotes as CSV cells', () => {
  assert.equal(exportTasks({ role: 'editor', tasks: [{ ...task, title: 'Meeting, "review"' }] }), 'id,title,status\n"DEMO-01","Meeting, ""review""","open"');
});

test('exports input with formula prefixes and leading spaces as strings', () => {
  assert.match(exportTasks({ role: 'owner', tasks: [{ ...task, title: ' =1+1' }] }), /"' =1\+1"/);
});

test('rejects undefined statuses and missing fields', () => {
  assert.throws(() => exportTasks({ role: 'editor', tasks: [{ ...task, status: 'unknown' }] }), /INVALID_TASK/);
  assert.throws(() => exportTasks({ role: 'editor', tasks: [{}] }), /INVALID_TASK/);
});
