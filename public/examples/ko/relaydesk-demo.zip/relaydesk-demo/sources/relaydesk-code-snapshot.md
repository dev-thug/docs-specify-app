# RelayDesk Demo 코드 스냅샷 1.4

문서 ID: RD-CODE-14. 소스 커밋: af26ee9. 이 문서는 합성 예제 코드의 고정된 사본이며 이후 저장소 변경을 자동으로 반영하지 않습니다. 실제 서비스의 배포·보안 통제 구현을 주장하는 자료가 아닙니다.

## package.json

```json
{
  "name": "relaydesk-demo",
  "version": "1.4.0",
  "private": true,
  "type": "module",
  "engines": { "node": ">=24" },
  "scripts": { "test": "node --test test/*.test.js", "demo": "node src/demo.js" }
}
```

## src/export-tasks.js

```javascript
export const EXPORT_LIMIT = 1000;

// 이 예제는 호출자가 전달한 역할만 검사한다. 로그인과 권한 발급 계층은 구현 범위 밖이다.
export function exportTasks({ role, tasks }) {
  if (!['owner', 'editor'].includes(role)) throw new Error('ACCESS_DENIED');
  if (!Array.isArray(tasks)) throw new Error('INVALID_TASK_LIST');
  if (tasks.length > EXPORT_LIMIT) throw new Error('EXPORT_LIMIT_EXCEEDED');
  const rows = tasks.map(task => {
    if (!task || typeof task.id !== 'string' || typeof task.title !== 'string' || !['open', 'done'].includes(task.status)) {
      throw new Error('INVALID_TASK');
    }
    return [task.id, task.title, task.status].map(csvCell).join(',');
  });
  return ['id,title,status', ...rows].join('\n');
}

function csvCell(value) {
  const text = /^[=+@-]/.test(value.trimStart()) ? "'" + value : value;
  return '"' + text.replaceAll('"', '""') + '"';
}
```

## src/demo.js

```javascript
import { exportTasks } from './export-tasks.js';

console.log(exportTasks({
  role: 'editor',
  tasks: [
    { id: 'DEMO-01', title: '고객 안내 검토', status: 'open' },
    { id: 'DEMO-02', title: '인수인계 문서 정리', status: 'done' },
  ],
}));
```

## test/export-tasks.test.js

```javascript
import test from 'node:test';
import assert from 'node:assert/strict';
import { exportTasks } from '../src/export-tasks.js';

const task = { id: 'DEMO-01', title: '샘플 업무', status: 'open' };

test('소유자와 편집자는 내보낼 수 있고 뷰어는 거부된다', () => {
  for (const role of ['owner', 'editor']) assert.match(exportTasks({ role, tasks: [task] }), /DEMO-01/);
  assert.throws(() => exportTasks({ role: 'viewer', tasks: [task] }), /ACCESS_DENIED/);
});

test('1,000건은 허용하고 초과하면 잘라내지 않고 거부한다', () => {
  assert.equal(exportTasks({ role: 'owner', tasks: Array(1000).fill(task) }).split('\n').length, 1001);
  assert.throws(() => exportTasks({ role: 'owner', tasks: Array(1001).fill(task) }), /EXPORT_LIMIT_EXCEEDED/);
});

test('쉼표와 따옴표를 CSV 셀 형식으로 이스케이프한다', () => {
  assert.equal(exportTasks({ role: 'editor', tasks: [{ ...task, title: '회의, "검토"' }] }), 'id,title,status\n"DEMO-01","회의, ""검토""","open"');
});

test('수식 접두사와 앞 공백을 포함한 입력을 문자열로 내보낸다', () => {
  assert.match(exportTasks({ role: 'owner', tasks: [{ ...task, title: ' =1+1' }] }), /"' =1\+1"/);
});

test('정의하지 않은 상태와 누락된 필드를 거부한다', () => {
  assert.throws(() => exportTasks({ role: 'editor', tasks: [{ ...task, status: 'unknown' }] }), /INVALID_TASK/);
  assert.throws(() => exportTasks({ role: 'editor', tasks: [{}] }), /INVALID_TASK/);
});
```

## CHANGELOG.md

```markdown
# 변경 기록

## 1.4.0 — 문서화 시연 버전

- `exportTasks`로 업무 목록 CSV 내보내기 추가.
- 소유자와 편집자 역할 허용. 뷰어 거부.
- 한 번에 최대 1,000건이며, 초과 요청을 조용히 잘라내지 않고 거부.
- 셀의 쉼표·따옴표와 수식 접두사 처리.
- 외부 의존성 없이 동작하는 테스트와 합성 입력 예제 추가.

ZIP 첨부파일 다운로드, 웹 UI, 인증 서버, 저장소 암호화 및 실제 배포는 구현하지 않았습니다. `sources/`의 정책 자료는 RAG 시연용 가상 입력이며 이 라이브러리에서 구현했다는 증거가 아닙니다.
```
